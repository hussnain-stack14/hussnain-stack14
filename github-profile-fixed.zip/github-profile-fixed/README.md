<div align="center">

<img width="100%" alt="Hussnain Ali - Full Stack Developer" src="https://capsule-render.vercel.app/api?type=waving&height=230&color=0:141414,45:1A1A1D,100:0891B2&text=Hussnain%20Ali&fontColor=67E8F9&fontSize=58&fontAlignY=38&desc=Full%20Stack%20Developer%20%7C%20Next.js%20%26%20MERN%20Stack&descAlignY=60&descSize=19&animation=fadeIn" />

### Building thoughtful digital experiences, one commit at a time.

[![Portfolio](https://img.shields.io/badge/PORTFOLIO-67E8F9?style=for-the-badge&logo=vercel&logoColor=141414)](https://hussnainali-portfolio.vercel.app/)
[![LinkedIn](https://img.shields.io/badge/LINKEDIN-27272A?style=for-the-badge&logo=linkedin&logoColor=67E8F9)](https://www.linkedin.com/in/hussnain-ali-01161a3a0/)
[![Email](https://img.shields.io/badge/EMAIL-27272A?style=for-the-badge&logo=gmail&logoColor=67E8F9)](mailto:hussnain.stack@gmail.com)

</div>

---

### 👨‍💻 About Me

I'm a **Software Engineering student at NUML** and a **Full Stack Developer** focused on Next.js and the MERN stack. I enjoy turning real problems into useful, responsive web applications.

- 🎓 **7th semester** — BS Software Engineering
- 🚌 Building **Smart Safar**, a real-time public transit tracking FYP
- 🏏 Developing **Crease**, an offline-first cricket scoring PWA
- ☁️ Exploring **AWS, cloud deployment and DevOps**
- 🤝 Open to internships, freelance projects and collaboration

### ⚡ Tech Stack

**Frontend**

[![Frontend](https://skillicons.dev/icons?i=html,css,js,react,nextjs,tailwind&theme=dark)](https://skillicons.dev)

**Backend & Database**

[![Backend](https://skillicons.dev/icons?i=nodejs,express,mongodb&theme=dark)](https://skillicons.dev)

**Tools & Cloud**

[![Tools](https://skillicons.dev/icons?i=git,github,vscode,vercel,netlify,aws&theme=dark)](https://skillicons.dev)

### 🚀 Featured Projects

<table>
<tr>
<td width="33%" valign="top">

#### 🚌 Smart Safar
**Final Year Project**

Real-time public transit tracking with routes, stops, live buses, bookings and an admin dashboard.

`Next.js` `Node.js` `MongoDB` `Socket.IO`

[**Source Code ↗**](https://github.com/hussnain-stack14/Smart-Public-Transit-Tracking-System)

</td>
<td width="33%" valign="top">

#### 🏏 Crease
**Offline-first PWA**

Cricket scoring with match statistics, player records and team accounts.

`Next.js` `PWA` `Offline-first`

[**Live App ↗**](https://crease-scoring.vercel.app/) · [**Code ↗**](https://github.com/hussnain-stack14/Cricket-Scoring-Web-App-)

</td>
<td width="33%" valign="top">

#### 🛒 EchoShop
**MERN E-commerce**

Full-stack shopping application with authentication and product management.

`React` `Express` `MongoDB` `JWT`

[**Live App ↗**](https://echoshop-hussnain.netlify.app/)

</td>
</tr>
</table>

### 📈 GitHub Activity

<div align="center">

<img width="49%" alt="GitHub stats" src="https://github-readme-stats.vercel.app/api?username=hussnain-stack14&show_icons=true&hide_border=true&bg_color=141414&title_color=67E8F9&text_color=FFFFFF&icon_color=67E8F9" />
<img width="49%" alt="Top languages" src="https://github-readme-stats.vercel.app/api/top-langs/?username=hussnain-stack14&layout=compact&hide_border=true&bg_color=141414&title_color=67E8F9&text_color=FFFFFF" />

</div>

### 🌐 Let's Connect

Have a project or opportunity in mind? I'd love to hear from you.

[**Portfolio ↗**](https://hussnainali-portfolio.vercel.app/) · [**LinkedIn ↗**](https://www.linkedin.com/in/hussnain-ali-01161a3a0/) · [**Email ↗**](mailto:hussnain.stack@gmail.com)

---

<div align="center">

**Code · Create · Innovate**

<sub>Designed around my portfolio's charcoal + cyan aesthetic.</sub>

</div>
